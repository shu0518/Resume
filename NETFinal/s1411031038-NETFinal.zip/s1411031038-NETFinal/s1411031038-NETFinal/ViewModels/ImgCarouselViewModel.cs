﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using s1411031038_NETFinal.Models;

namespace s1411031038_NETFinal.ViewModels
{
    public class ImgCarouselViewModel
    {
        public List<ImgCarousel> DataList { get; set; }
    }
}