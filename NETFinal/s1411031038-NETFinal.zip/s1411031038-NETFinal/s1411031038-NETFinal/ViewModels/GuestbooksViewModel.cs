﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using s1411031038_NETFinal.Models;

namespace s1411031038_NETFinal.ViewModels
{
    public class GuestbooksViewModel
    {
        //顯示資料陣列
        public List<Guestbooks> DataList { get; set; }
    }
}