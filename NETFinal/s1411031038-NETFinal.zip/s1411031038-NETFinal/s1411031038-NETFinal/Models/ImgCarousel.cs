﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace s1411031038_NETFinal.Models
{
    public class ImgCarousel
    {
        public int pid { get; set; }
        public string pfile { get; set; }
        public string ptitle { get; set; }
        public string pinfo { get; set; }

    }
}